from pymongo import MongoClient

class AnimalShelter:
    """CRUD operations for Animal collection in MongoDB"""

    def __init__(self, username, password):
        self.client = MongoClient(f"mongodb://{username}:{password}@nv-desktop-services.apporto.com:34214/?directConnection=true&appName=mongosh+1.8.0")
        self.database = self.client['aac']
        self.collection = self.database['animals']

    def create(self, data):
        """Insert a document into the collection."""
        if data:
            self.collection.insert_one(data)
            return True
        else:
            raise ValueError("Data cannot be empty")

    def read(self, query):
        """Find documents in the collection based on a query."""
        return list(self.collection.find(query))
